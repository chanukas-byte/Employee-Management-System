#include "database/DatabaseManager.h"
#include <wx/wx.h>

DatabaseManager& DatabaseManager::getInstance() {
    static DatabaseManager instance;
    return instance;
}

DatabaseManager::DatabaseManager() : m_db(nullptr) {
}

DatabaseManager::~DatabaseManager() {
    if (m_db) {
        sqlite3_close(m_db);
    }
}

bool DatabaseManager::initialize() {
    int rc = sqlite3_open("employee_management.db", &m_db);
    if (rc) {
        wxLogError("Can't open database: %s", sqlite3_errmsg(m_db));
        return false;
    }
    return createTables();
}

bool DatabaseManager::createTables() {
    const char* sql = 
        "CREATE TABLE IF NOT EXISTS employees ("
        "email TEXT PRIMARY KEY,"
        "first_name TEXT NOT NULL,"
        "last_name TEXT NOT NULL,"
        "mobile TEXT,"
        "address TEXT,"
        "age INTEGER,"
        "gender TEXT,"
        "salary REAL DEFAULT 0.0,"
        "attendance INTEGER DEFAULT 0"
        ");";
    
    return executeQuery(sql);
}

bool DatabaseManager::executeQuery(const std::string& query) {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(m_db, query.c_str(), nullptr, nullptr, &errMsg);
    
    if (rc != SQLITE_OK) {
        wxLogError("SQL error: %s", errMsg);
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}

bool DatabaseManager::addEmployee(const Employee& employee) {
    std::string query = wxString::Format(
        "INSERT INTO employees (email, first_name, last_name, mobile, address, age, gender) "
        "VALUES ('%s', '%s', '%s', '%s', '%s', %d, '%s');",
        employee.GetEmail().ToStdString(),
        employee.GetFirstName().ToStdString(),
        employee.GetLastName().ToStdString(),
        employee.GetMobile().ToStdString(),
        employee.GetAddress().ToStdString(),
        employee.GetAge(),
        employee.GetGender().ToStdString()
    ).ToStdString();
    
    return executeQuery(query);
}

bool DatabaseManager::updateEmployee(const Employee& employee) {
    std::string query = wxString::Format(
        "UPDATE employees SET "
        "first_name = '%s', "
        "last_name = '%s', "
        "mobile = '%s', "
        "address = '%s', "
        "age = %d, "
        "gender = '%s' "
        "WHERE email = '%s';",
        employee.GetFirstName().ToStdString(),
        employee.GetLastName().ToStdString(),
        employee.GetMobile().ToStdString(),
        employee.GetAddress().ToStdString(),
        employee.GetAge(),
        employee.GetGender().ToStdString(),
        employee.GetEmail().ToStdString()
    ).ToStdString();
    
    return executeQuery(query);
}

bool DatabaseManager::deleteEmployee(const std::string& email) {
    std::string query = "DELETE FROM employees WHERE email = '" + email + "';";
    return executeQuery(query);
}

std::vector<Employee> DatabaseManager::getAllEmployees() {
    std::vector<Employee> employees;
    const char* sql = "SELECT * FROM employees;";
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(m_db, sql, -1, &stmt, nullptr);
    
    if (rc == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            Employee emp;
            emp.SetEmail(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 0)));
            emp.SetFirstName(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 1)));
            emp.SetLastName(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 2)));
            emp.SetMobile(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 3)));
            emp.SetAddress(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 4)));
            emp.SetAge(sqlite3_column_int(stmt, 5));
            emp.SetGender(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 6)));
            emp.SetSalary(sqlite3_column_double(stmt, 7));
            emp.SetAttendance(sqlite3_column_int(stmt, 8) != 0);
            
            employees.push_back(emp);
        }
    }
    
    sqlite3_finalize(stmt);
    return employees;
}

Employee DatabaseManager::getEmployeeByEmail(const std::string& email) {
    Employee emp;
    std::string query = "SELECT * FROM employees WHERE email = '" + email + "';";
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(m_db, query.c_str(), -1, &stmt, nullptr);
    
    if (rc == SQLITE_OK && sqlite3_step(stmt) == SQLITE_ROW) {
        emp.SetEmail(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 0)));
        emp.SetFirstName(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 1)));
        emp.SetLastName(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 2)));
        emp.SetMobile(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 3)));
        emp.SetAddress(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 4)));
        emp.SetAge(sqlite3_column_int(stmt, 5));
        emp.SetGender(wxString::FromUTF8((const char*)sqlite3_column_text(stmt, 6)));
        emp.SetSalary(sqlite3_column_double(stmt, 7));
        emp.SetAttendance(sqlite3_column_int(stmt, 8) != 0);
    }
    
    sqlite3_finalize(stmt);
    return emp;
}

bool DatabaseManager::setEmployeeAttendance(const std::string& email, bool attendance) {
    std::string query = wxString::Format(
        "UPDATE employees SET attendance = %d WHERE email = '%s';",
        attendance ? 1 : 0,
        email
    ).ToStdString();
    return executeQuery(query);
}

bool DatabaseManager::setEmployeeSalary(const std::string& email, double salary) {
    std::string query = wxString::Format(
        "UPDATE employees SET salary = %.2f WHERE email = '%s';",
        salary,
        email
    ).ToStdString();
    return executeQuery(query);
} 