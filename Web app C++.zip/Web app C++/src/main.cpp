#include <wx/wx.h>
#include "ui/LoginFrame.h"
#include "ui/RegistrationDialog.h"
#include "database/DatabaseManager.h"
#include "auth/AuthManager.h"

class EmployeeManagementApp : public wxApp {
public:
    virtual bool OnInit() {
        if (!wxApp::OnInit())
            return false;

        // Initialize database
        if (!DatabaseManager::getInstance().initialize()) {
            wxMessageBox("Failed to initialize database", "Error", wxOK | wxICON_ERROR);
            return false;
        }

        // Initialize authentication
        if (!AuthManager::getInstance().initialize()) {
            wxMessageBox("Failed to initialize authentication", "Error", wxOK | wxICON_ERROR);
            return false;
        }

        // Show registration dialog first
        RegistrationDialog regDialog(nullptr);
        if (regDialog.ShowModal() == wxID_OK) {
            // Register the user
            if (!AuthManager::getInstance().registerUser(
                    regDialog.GetUserId(),
                    regDialog.GetPassword(),
                    regDialog.GetRole())) {
                wxMessageBox("Registration failed. User may already exist.", "Error", wxOK | wxICON_ERROR);
                return false;
            } else {
                wxMessageBox("Registration successful! Please log in.", "Success", wxOK | wxICON_INFORMATION);
            }
        } else {
            // User cancelled registration
            return false;
        }

        // Create and show the login frame
        LoginFrame* frame = new LoginFrame("Employee Management System");
        frame->Show(true);
        return true;
    }
};

wxIMPLEMENT_APP(EmployeeManagementApp); 