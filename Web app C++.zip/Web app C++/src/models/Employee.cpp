#include "models/Employee.h"

Employee::Employee()
    : m_age(0)
    , m_salary(0.0)
    , m_attendance(false)
{
}

Employee::Employee(const wxString& firstName, const wxString& lastName, const wxString& mobile,
                 const wxString& address, int age, const wxString& gender, const wxString& email)
    : m_firstName(firstName)
    , m_lastName(lastName)
    , m_mobile(mobile)
    , m_address(address)
    , m_age(age)
    , m_gender(gender)
    , m_email(email)
    , m_salary(0.0)
    , m_attendance(false)
{
} 