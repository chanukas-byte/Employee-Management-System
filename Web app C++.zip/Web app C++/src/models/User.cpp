#include "models/User.h"

User::User()
    : m_role(UserRole::Employee)
{
}

User::User(const wxString& userId, const wxString& password, UserRole role)
    : m_userId(userId)
    , m_password(password)
    , m_role(role)
{
} 