#include "auth/AuthManager.h"
#include <wx/wx.h>

AuthManager& AuthManager::getInstance() {
    static AuthManager instance;
    return instance;
}

AuthManager::AuthManager() : m_db(nullptr) {
}

AuthManager::~AuthManager() {
    if (m_db) {
        sqlite3_close(m_db);
    }
}

bool AuthManager::initialize() {
    int rc = sqlite3_open("employee_management.db", &m_db);
    if (rc) {
        wxLogError("Can't open database: %s", sqlite3_errmsg(m_db));
        return false;
    }
    return createTables();
}

bool AuthManager::createTables() {
    const char* sql = 
        "CREATE TABLE IF NOT EXISTS users ("
        "user_id TEXT PRIMARY KEY,"
        "password TEXT NOT NULL,"
        "role INTEGER NOT NULL"
        ");";
    
    return executeQuery(sql);
}

bool AuthManager::executeQuery(const std::string& query) {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(m_db, query.c_str(), nullptr, nullptr, &errMsg);
    
    if (rc != SQLITE_OK) {
        wxLogError("SQL error: %s", errMsg);
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}

bool AuthManager::authenticate(const wxString& userId, const wxString& password, UserRole& role) {
    std::string query = wxString::Format(
        "SELECT role FROM users WHERE user_id = '%s' AND password = '%s';",
        userId.ToStdString(),
        password.ToStdString()
    ).ToStdString();
    
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(m_db, query.c_str(), -1, &stmt, nullptr);
    
    bool success = false;
    if (rc == SQLITE_OK && sqlite3_step(stmt) == SQLITE_ROW) {
        role = static_cast<UserRole>(sqlite3_column_int(stmt, 0));
        success = true;
    }
    
    sqlite3_finalize(stmt);
    return success;
}

bool AuthManager::registerUser(const wxString& userId, const wxString& password, UserRole role) {
    std::string query = wxString::Format(
        "INSERT INTO users (user_id, password, role) VALUES ('%s', '%s', %d);",
        userId.ToStdString(),
        password.ToStdString(),
        static_cast<int>(role)
    ).ToStdString();
    
    return executeQuery(query);
}

bool AuthManager::changePassword(const wxString& userId, const wxString& oldPassword, const wxString& newPassword) {
    std::string query = wxString::Format(
        "UPDATE users SET password = '%s' WHERE user_id = '%s' AND password = '%s';",
        newPassword.ToStdString(),
        userId.ToStdString(),
        oldPassword.ToStdString()
    ).ToStdString();
    
    return executeQuery(query);
} 