#include "ui/EmployeeDashboard.h"
#include "database/DatabaseManager.h"

BEGIN_EVENT_TABLE(EmployeeDashboard, wxFrame)
    EVT_BUTTON(wxID_ANY, EmployeeDashboard::OnViewDetails)
    EVT_BUTTON(wxID_ANY, EmployeeDashboard::OnViewAttendance)
    EVT_BUTTON(wxID_ANY, EmployeeDashboard::OnViewSalary)
END_EVENT_TABLE()

EmployeeDashboard::EmployeeDashboard(const wxString& title)
    : wxFrame(nullptr, wxID_ANY, title, wxDefaultPosition, wxSize(600, 400))
{
    CreateControls();
    LayoutControls();
    RefreshEmployeeGrid();
    Centre();
}

void EmployeeDashboard::CreateControls()
{
    // Create main panel
    wxPanel* panel = new wxPanel(this);

    // Create grid
    m_employeeGrid = new wxGrid(panel, wxID_ANY);
    m_employeeGrid->CreateGrid(1, 8);
    m_employeeGrid->SetColLabelValue(0, "First Name");
    m_employeeGrid->SetColLabelValue(1, "Last Name");
    m_employeeGrid->SetColLabelValue(2, "Mobile");
    m_employeeGrid->SetColLabelValue(3, "Address");
    m_employeeGrid->SetColLabelValue(4, "Age");
    m_employeeGrid->SetColLabelValue(5, "Gender");
    m_employeeGrid->SetColLabelValue(6, "Email");
    m_employeeGrid->SetColLabelValue(7, "Salary");

    // Create buttons
    m_viewDetailsButton = new wxButton(panel, wxID_ANY, "View Details");
    m_viewAttendanceButton = new wxButton(panel, wxID_ANY, "View Attendance");
    m_viewSalaryButton = new wxButton(panel, wxID_ANY, "View Salary");
}

void EmployeeDashboard::LayoutControls()
{
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* buttonSizer = new wxBoxSizer(wxHORIZONTAL);

    // Add buttons
    buttonSizer->Add(m_viewDetailsButton, 0, wxALL, 5);
    buttonSizer->Add(m_viewAttendanceButton, 0, wxALL, 5);
    buttonSizer->Add(m_viewSalaryButton, 0, wxALL, 5);

    // Add all to main sizer
    mainSizer->Add(m_employeeGrid, 1, wxEXPAND | wxALL, 5);
    mainSizer->Add(buttonSizer, 0, wxALIGN_CENTER | wxALL, 5);

    SetSizer(mainSizer);
}

void EmployeeDashboard::RefreshEmployeeGrid()
{
    // TODO: Load employee data from database
    m_employeeGrid->SetCellValue(0, 0, m_employee.GetFirstName());
    m_employeeGrid->SetCellValue(0, 1, m_employee.GetLastName());
    m_employeeGrid->SetCellValue(0, 2, m_employee.GetMobile());
    m_employeeGrid->SetCellValue(0, 3, m_employee.GetAddress());
    m_employeeGrid->SetCellValue(0, 4, wxString::Format("%d", m_employee.GetAge()));
    m_employeeGrid->SetCellValue(0, 5, m_employee.GetGender());
    m_employeeGrid->SetCellValue(0, 6, m_employee.GetEmail());
    m_employeeGrid->SetCellValue(0, 7, wxString::Format("%.2f", m_employee.GetSalary()));

    m_employeeGrid->AutoSizeColumns();
}

void EmployeeDashboard::OnViewDetails(wxCommandEvent& event)
{
    // TODO: Show detailed employee information
    wxMessageBox("View details functionality will be implemented here", "Information", wxOK | wxICON_INFORMATION);
}

void EmployeeDashboard::OnViewAttendance(wxCommandEvent& event)
{
    // TODO: Show attendance information
    wxMessageBox("View attendance functionality will be implemented here", "Information", wxOK | wxICON_INFORMATION);
}

void EmployeeDashboard::OnViewSalary(wxCommandEvent& event)
{
    // TODO: Show salary information
    wxMessageBox("View salary functionality will be implemented here", "Information", wxOK | wxICON_INFORMATION);
} 