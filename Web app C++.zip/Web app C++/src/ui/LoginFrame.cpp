#include "ui/LoginFrame.h"
#include "ui/EmployeeDashboard.h"
#include "ui/ManagerDashboard.h"
#include "ui/AdminDashboard.h"
#include "ui/AccountantDashboard.h"
#include "auth/AuthManager.h"

BEGIN_EVENT_TABLE(LoginFrame, wxFrame)
    EVT_BUTTON(wxID_ANY, LoginFrame::OnLogin)
    EVT_BUTTON(wxID_ANY, LoginFrame::OnRegister)
END_EVENT_TABLE()

LoginFrame::LoginFrame(const wxString& title)
    : wxFrame(nullptr, wxID_ANY, title, wxDefaultPosition, wxSize(420, 360))
{
    CreateControls();
    LayoutControls();
    Centre();
    m_userIdCtrl->SetFocus();
}

void LoginFrame::CreateControls()
{
    wxPanel* panel = new wxPanel(this);

    // Create controls with placeholder text and larger size
    m_userIdCtrl = new wxTextCtrl(panel, wxID_ANY, "", wxDefaultPosition, wxSize(250, 32));
    m_userIdCtrl->SetHint("Enter your user ID");
    m_passwordCtrl = new wxTextCtrl(panel, wxID_ANY, "", wxDefaultPosition, wxSize(250, 32), wxTE_PASSWORD);
    m_passwordCtrl->SetHint("Enter your password");
    m_loginButton = new wxButton(panel, wxID_ANY, "Login", wxDefaultPosition, wxSize(100, 36));
    m_registerButton = new wxButton(panel, wxID_ANY, "Register", wxDefaultPosition, wxSize(100, 36));

    // Show Password checkbox
    m_showPasswordCheck = new wxCheckBox(panel, wxID_ANY, "Show Password");
    m_showPasswordCheck->Bind(wxEVT_CHECKBOX, &LoginFrame::OnShowPassword, this);

    SetClientData(panel);
}

void LoginFrame::LayoutControls()
{
    wxPanel* panel = static_cast<wxPanel*>(GetClientData());
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);

    // Title
    wxStaticText* titleText = new wxStaticText(panel, wxID_ANY, "Login to Employee Management System");
    wxFont titleFont = titleText->GetFont();
    titleFont.SetPointSize(13);
    titleFont.SetWeight(wxFONTWEIGHT_BOLD);
    titleText->SetFont(titleFont);
    mainSizer->Add(titleText, 0, wxALIGN_CENTER | wxTOP | wxBOTTOM, 15);

    // Instructions
    wxStaticText* instructions = new wxStaticText(panel, wxID_ANY, "Please enter your User ID and Password.");
    mainSizer->Add(instructions, 0, wxALIGN_CENTER | wxBOTTOM, 10);

    // Form grid
    wxFlexGridSizer* formSizer = new wxFlexGridSizer(2, 2, 15, 15);
    formSizer->AddGrowableCol(1, 1);
    formSizer->Add(new wxStaticText(panel, wxID_ANY, "User ID:"), 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
    formSizer->Add(m_userIdCtrl, 1, wxEXPAND);
    formSizer->Add(new wxStaticText(panel, wxID_ANY, "Password:"), 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
    formSizer->Add(m_passwordCtrl, 1, wxEXPAND);
    mainSizer->Add(formSizer, 0, wxEXPAND | wxLEFT | wxRIGHT, 30);

    // Show Password checkbox
    mainSizer->Add(m_showPasswordCheck, 0, wxALIGN_RIGHT | wxRIGHT | wxTOP, 40);

    // Buttons
    wxBoxSizer* buttonSizer = new wxBoxSizer(wxHORIZONTAL);
    buttonSizer->AddStretchSpacer(1);
    buttonSizer->Add(m_loginButton, 0, wxALL, 10);
    buttonSizer->Add(m_registerButton, 0, wxALL, 10);
    buttonSizer->AddStretchSpacer(1);
    mainSizer->Add(buttonSizer, 0, wxEXPAND | wxTOP, 10);

    panel->SetSizer(mainSizer);
}

void LoginFrame::OnShowPassword(wxCommandEvent& event)
{
    long style = wxTE_PROCESS_ENTER;
    if (!m_showPasswordCheck->IsChecked()) style |= wxTE_PASSWORD;
    m_passwordCtrl->SetWindowStyleFlag(style);
}

void LoginFrame::OnLogin(wxCommandEvent& event)
{
    wxString userId = m_userIdCtrl->GetValue();
    wxString password = m_passwordCtrl->GetValue();

    if (userId.IsEmpty() || password.IsEmpty()) {
        wxMessageBox("Please enter both user ID and password", "Error", wxOK | wxICON_ERROR);
        return;
    }

    UserRole role;
    if (AuthManager::getInstance().authenticate(userId, password, role)) {
        wxFrame* dashboard = nullptr;
        switch (role) {
            case UserRole::Employee:
                dashboard = new EmployeeDashboard("Employee Dashboard");
                break;
            case UserRole::Manager:
                dashboard = new ManagerDashboard("Manager Dashboard");
                break;
            case UserRole::Administrator:
                dashboard = new AdminDashboard("Admin Dashboard");
                break;
            case UserRole::Accountant:
                dashboard = new AccountantDashboard("Accountant Dashboard");
                break;
        }
        if (dashboard) {
            dashboard->Show(true);
            this->Show(false);
        }
    } else {
        wxMessageBox("Invalid user ID or password", "Error", wxOK | wxICON_ERROR);
    }
}

void LoginFrame::OnRegister(wxCommandEvent& event)
{
    wxMessageBox("Registration functionality will be implemented here", "Information", wxOK | wxICON_INFORMATION);
} 