#include "ui/AccountantDashboard.h"
#include "database/DatabaseManager.h"

BEGIN_EVENT_TABLE(AccountantDashboard, wxFrame)
    EVT_BUTTON(wxID_ANY, AccountantDashboard::OnViewDetails)
    EVT_BUTTON(wxID_ANY, AccountantDashboard::OnSetSalary)
    EVT_TEXT(wxID_ANY, AccountantDashboard::OnSearch)
END_EVENT_TABLE()

AccountantDashboard::AccountantDashboard(const wxString& title)
    : wxFrame(nullptr, wxID_ANY, title, wxDefaultPosition, wxSize(800, 600))
{
    CreateControls();
    LayoutControls();
    RefreshEmployeeGrid();
    Centre();
}

void AccountantDashboard::CreateControls()
{
    // Create main panel
    wxPanel* panel = new wxPanel(this);

    // Create grid
    m_employeeGrid = new wxGrid(panel, wxID_ANY);
    m_employeeGrid->CreateGrid(0, 8);
    m_employeeGrid->SetColLabelValue(0, "First Name");
    m_employeeGrid->SetColLabelValue(1, "Last Name");
    m_employeeGrid->SetColLabelValue(2, "Mobile");
    m_employeeGrid->SetColLabelValue(3, "Address");
    m_employeeGrid->SetColLabelValue(4, "Age");
    m_employeeGrid->SetColLabelValue(5, "Gender");
    m_employeeGrid->SetColLabelValue(6, "Email");
    m_employeeGrid->SetColLabelValue(7, "Salary");

    // Create buttons
    m_viewDetailsButton = new wxButton(panel, wxID_ANY, "View Details");
    m_setSalaryButton = new wxButton(panel, wxID_ANY, "Set Salary");

    // Create search control
    m_searchCtrl = new wxTextCtrl(panel, wxID_ANY, "", wxDefaultPosition, wxDefaultSize, wxTE_PROCESS_ENTER);
}

void AccountantDashboard::LayoutControls()
{
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* buttonSizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* searchSizer = new wxBoxSizer(wxHORIZONTAL);

    // Add search controls
    searchSizer->Add(new wxStaticText(this, wxID_ANY, "Search:"), 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 5);
    searchSizer->Add(m_searchCtrl, 1, wxEXPAND);

    // Add buttons
    buttonSizer->Add(m_viewDetailsButton, 0, wxALL, 5);
    buttonSizer->Add(m_setSalaryButton, 0, wxALL, 5);

    // Add all to main sizer
    mainSizer->Add(searchSizer, 0, wxEXPAND | wxALL, 5);
    mainSizer->Add(m_employeeGrid, 1, wxEXPAND | wxALL, 5);
    mainSizer->Add(buttonSizer, 0, wxALIGN_CENTER | wxALL, 5);

    SetSizer(mainSizer);
}

void AccountantDashboard::RefreshEmployeeGrid()
{
    // Clear existing rows
    if (m_employeeGrid->GetNumberRows() > 0) {
        m_employeeGrid->DeleteRows(0, m_employeeGrid->GetNumberRows());
    }

    // Add employees to grid
    for (const auto& employee : m_employees) {
        int row = m_employeeGrid->GetNumberRows();
        m_employeeGrid->AppendRows(1);
        m_employeeGrid->SetCellValue(row, 0, employee.GetFirstName());
        m_employeeGrid->SetCellValue(row, 1, employee.GetLastName());
        m_employeeGrid->SetCellValue(row, 2, employee.GetMobile());
        m_employeeGrid->SetCellValue(row, 3, employee.GetAddress());
        m_employeeGrid->SetCellValue(row, 4, wxString::Format("%d", employee.GetAge()));
        m_employeeGrid->SetCellValue(row, 5, employee.GetGender());
        m_employeeGrid->SetCellValue(row, 6, employee.GetEmail());
        m_employeeGrid->SetCellValue(row, 7, wxString::Format("%.2f", employee.GetSalary()));
    }

    m_employeeGrid->AutoSizeColumns();
}

void AccountantDashboard::OnViewDetails(wxCommandEvent& event)
{
    int row = m_employeeGrid->GetSelectedRows().IsEmpty() ? -1 : m_employeeGrid->GetSelectedRows()[0];
    if (row >= 0 && row < m_employees.size()) {
        // TODO: Show detailed employee information
        wxMessageBox("View details functionality will be implemented here", "Information", wxOK | wxICON_INFORMATION);
    } else {
        wxMessageBox("Please select an employee to view details", "Error", wxOK | wxICON_ERROR);
    }
}

void AccountantDashboard::OnSetSalary(wxCommandEvent& event)
{
    int row = m_employeeGrid->GetSelectedRows().IsEmpty() ? -1 : m_employeeGrid->GetSelectedRows()[0];
    if (row >= 0 && row < m_employees.size()) {
        ShowSetSalaryDialog(row);
    } else {
        wxMessageBox("Please select an employee to set salary", "Error", wxOK | wxICON_ERROR);
    }
}

void AccountantDashboard::OnSearch(wxCommandEvent& event)
{
    wxString searchText = m_searchCtrl->GetValue().Lower();
    if (searchText.IsEmpty()) {
        RefreshEmployeeGrid();
        return;
    }

    // Filter employees based on search text
    std::vector<Employee> filteredEmployees;
    for (const auto& employee : m_employees) {
        if (employee.GetFirstName().Lower().Contains(searchText) ||
            employee.GetLastName().Lower().Contains(searchText) ||
            employee.GetEmail().Lower().Contains(searchText) ||
            employee.GetMobile().Contains(searchText)) {
            filteredEmployees.push_back(employee);
        }
    }

    // Update grid with filtered results
    m_employeeGrid->DeleteRows(0, m_employeeGrid->GetNumberRows());
    for (const auto& employee : filteredEmployees) {
        int row = m_employeeGrid->GetNumberRows();
        m_employeeGrid->AppendRows(1);
        m_employeeGrid->SetCellValue(row, 0, employee.GetFirstName());
        m_employeeGrid->SetCellValue(row, 1, employee.GetLastName());
        m_employeeGrid->SetCellValue(row, 2, employee.GetMobile());
        m_employeeGrid->SetCellValue(row, 3, employee.GetAddress());
        m_employeeGrid->SetCellValue(row, 4, wxString::Format("%d", employee.GetAge()));
        m_employeeGrid->SetCellValue(row, 5, employee.GetGender());
        m_employeeGrid->SetCellValue(row, 6, employee.GetEmail());
        m_employeeGrid->SetCellValue(row, 7, wxString::Format("%.2f", employee.GetSalary()));
    }
}

void AccountantDashboard::ShowSetSalaryDialog(int row)
{
    // TODO: Implement set salary dialog
    wxMessageBox("Set salary dialog will be implemented here", "Information", wxOK | wxICON_INFORMATION);
} 