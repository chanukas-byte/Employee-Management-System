#include "ui/RegistrationDialog.h"

BEGIN_EVENT_TABLE(RegistrationDialog, wxDialog)
    EVT_BUTTON(wxID_OK, RegistrationDialog::OnRegister)
    EVT_BUTTON(wxID_CANCEL, RegistrationDialog::OnCancel)
END_EVENT_TABLE()

RegistrationDialog::RegistrationDialog(wxWindow* parent)
    : wxDialog(parent, wxID_ANY, "Register New User", wxDefaultPosition, wxSize(350, 320))
{
    CreateControls();
    LayoutControls();
    Centre();
}

void RegistrationDialog::CreateControls()
{
    m_userIdCtrl = new wxTextCtrl(this, wxID_ANY, "", wxDefaultPosition, wxSize(200, 28));
    m_userIdCtrl->SetHint("Enter user ID");
    m_passwordCtrl = new wxTextCtrl(this, wxID_ANY, "", wxDefaultPosition, wxSize(200, 28), wxTE_PASSWORD);
    m_passwordCtrl->SetHint("Enter password");
    m_confirmPasswordCtrl = new wxTextCtrl(this, wxID_ANY, "", wxDefaultPosition, wxSize(200, 28), wxTE_PASSWORD);
    m_confirmPasswordCtrl->SetHint("Confirm password");
    wxArrayString roles;
    roles.Add("Employee");
    roles.Add("Manager");
    roles.Add("Administrator");
    roles.Add("Accountant");
    m_roleChoice = new wxChoice(this, wxID_ANY, wxDefaultPosition, wxDefaultSize, roles);
    m_roleChoice->SetSelection(0);
    m_registerButton = new wxButton(this, wxID_OK, "Register");
    m_cancelButton = new wxButton(this, wxID_CANCEL, "Cancel");
}

void RegistrationDialog::LayoutControls()
{
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    wxFlexGridSizer* formSizer = new wxFlexGridSizer(2, 2, 10, 10);
    formSizer->AddGrowableCol(1, 1);
    formSizer->Add(new wxStaticText(this, wxID_ANY, "User ID:"), 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
    formSizer->Add(m_userIdCtrl, 1, wxEXPAND);
    formSizer->Add(new wxStaticText(this, wxID_ANY, "Password:"), 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
    formSizer->Add(m_passwordCtrl, 1, wxEXPAND);
    formSizer->Add(new wxStaticText(this, wxID_ANY, "Confirm Password:"), 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
    formSizer->Add(m_confirmPasswordCtrl, 1, wxEXPAND);
    formSizer->Add(new wxStaticText(this, wxID_ANY, "Role:"), 0, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
    formSizer->Add(m_roleChoice, 1, wxEXPAND);
    mainSizer->Add(formSizer, 0, wxEXPAND | wxALL, 20);
    wxBoxSizer* buttonSizer = new wxBoxSizer(wxHORIZONTAL);
    buttonSizer->AddStretchSpacer(1);
    buttonSizer->Add(m_registerButton, 0, wxALL, 10);
    buttonSizer->Add(m_cancelButton, 0, wxALL, 10);
    buttonSizer->AddStretchSpacer(1);
    mainSizer->Add(buttonSizer, 0, wxEXPAND | wxBOTTOM, 10);
    SetSizer(mainSizer);
}

void RegistrationDialog::OnRegister(wxCommandEvent& event)
{
    wxString userId = m_userIdCtrl->GetValue();
    wxString password = m_passwordCtrl->GetValue();
    wxString confirmPassword = m_confirmPasswordCtrl->GetValue();
    if (userId.IsEmpty() || password.IsEmpty() || confirmPassword.IsEmpty()) {
        wxMessageBox("All fields are required.", "Error", wxOK | wxICON_ERROR);
        return;
    }
    if (password != confirmPassword) {
        wxMessageBox("Passwords do not match.", "Error", wxOK | wxICON_ERROR);
        return;
    }
    EndModal(wxID_OK);
}

void RegistrationDialog::OnCancel(wxCommandEvent& event)
{
    EndModal(wxID_CANCEL);
}

wxString RegistrationDialog::GetUserId() const {
    return m_userIdCtrl->GetValue();
}

wxString RegistrationDialog::GetPassword() const {
    return m_passwordCtrl->GetValue();
}

UserRole RegistrationDialog::GetRole() const {
    switch (m_roleChoice->GetSelection()) {
        case 0: return UserRole::Employee;
        case 1: return UserRole::Manager;
        case 2: return UserRole::Administrator;
        case 3: return UserRole::Accountant;
        default: return UserRole::Employee;
    }
} 