#pragma once

#include <sqlite3.h>
#include <string>
#include <vector>
#include "models/Employee.h"

class DatabaseManager {
public:
    static DatabaseManager& getInstance();
    
    bool initialize();
    bool addEmployee(const Employee& employee);
    bool updateEmployee(const Employee& employee);
    bool deleteEmployee(const std::string& email);
    std::vector<Employee> getAllEmployees();
    Employee getEmployeeByEmail(const std::string& email);
    bool setEmployeeAttendance(const std::string& email, bool attendance);
    bool setEmployeeSalary(const std::string& email, double salary);

private:
    DatabaseManager();
    ~DatabaseManager();
    
    sqlite3* m_db;
    bool createTables();
    bool executeQuery(const std::string& query);
}; 