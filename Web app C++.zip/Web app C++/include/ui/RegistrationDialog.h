#pragma once

#include <wx/wx.h>
#include "auth/AuthManager.h"

class RegistrationDialog : public wxDialog {
public:
    RegistrationDialog(wxWindow* parent);
    wxString GetUserId() const;
    wxString GetPassword() const;
    UserRole GetRole() const;

private:
    wxTextCtrl* m_userIdCtrl;
    wxTextCtrl* m_passwordCtrl;
    wxTextCtrl* m_confirmPasswordCtrl;
    wxChoice* m_roleChoice;
    wxButton* m_registerButton;
    wxButton* m_cancelButton;

    void OnRegister(wxCommandEvent& event);
    void OnCancel(wxCommandEvent& event);
    void CreateControls();
    void LayoutControls();

    DECLARE_EVENT_TABLE()
}; 