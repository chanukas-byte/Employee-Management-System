#pragma once

#include <wx/wx.h>
#include <wx/grid.h>
#include <vector>
#include "models/Employee.h"

class AdminDashboard : public wxFrame {
public:
    AdminDashboard(const wxString& title);

private:
    // UI Elements
    wxGrid* m_employeeGrid;
    wxButton* m_addButton;
    wxButton* m_editButton;
    wxButton* m_deleteButton;
    wxTextCtrl* m_searchCtrl;

    // Data
    std::vector<Employee> m_employees;

    // Event handlers
    void OnAdd(wxCommandEvent& event);
    void OnEdit(wxCommandEvent& event);
    void OnDelete(wxCommandEvent& event);
    void OnSearch(wxCommandEvent& event);

    // Helper functions
    void CreateControls();
    void LayoutControls();
    void RefreshEmployeeGrid();
    void ShowAddDialog();
    void ShowEditDialog(int row);

    DECLARE_EVENT_TABLE()
}; 