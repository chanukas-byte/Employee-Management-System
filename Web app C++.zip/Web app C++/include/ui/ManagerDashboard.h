#pragma once

#include <wx/wx.h>
#include <wx/grid.h>
#include <vector>
#include "models/Employee.h"

class ManagerDashboard : public wxFrame {
public:
    ManagerDashboard(const wxString& title);

private:
    // UI Elements
    wxGrid* m_employeeGrid;
    wxButton* m_viewDetailsButton;
    wxButton* m_setAttendanceButton;
    wxTextCtrl* m_searchCtrl;

    // Data
    std::vector<Employee> m_employees;

    // Event handlers
    void OnViewDetails(wxCommandEvent& event);
    void OnSetAttendance(wxCommandEvent& event);
    void OnSearch(wxCommandEvent& event);

    // Helper functions
    void CreateControls();
    void LayoutControls();
    void RefreshEmployeeGrid();
    void ShowSetAttendanceDialog(int row);

    DECLARE_EVENT_TABLE()
}; 