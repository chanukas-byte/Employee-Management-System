#pragma once

#include <wx/wx.h>
#include <wx/grid.h>
#include "models/Employee.h"

class EmployeeDashboard : public wxFrame {
public:
    EmployeeDashboard(const wxString& title);

private:
    // UI Elements
    wxGrid* m_employeeGrid;
    wxButton* m_viewDetailsButton;
    wxButton* m_viewAttendanceButton;
    wxButton* m_viewSalaryButton;

    // Data
    Employee m_employee;

    // Event handlers
    void OnViewDetails(wxCommandEvent& event);
    void OnViewAttendance(wxCommandEvent& event);
    void OnViewSalary(wxCommandEvent& event);

    // Helper functions
    void CreateControls();
    void LayoutControls();
    void RefreshEmployeeGrid();

    DECLARE_EVENT_TABLE()
}; 