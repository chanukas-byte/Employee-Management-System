#pragma once

#include <wx/wx.h>
#include "auth/AuthManager.h"

class LoginFrame : public wxFrame {
public:
    LoginFrame(const wxString& title);

private:
    // UI Elements
    wxTextCtrl* m_userIdCtrl;
    wxTextCtrl* m_passwordCtrl;
    wxButton* m_loginButton;
    wxButton* m_registerButton;
    wxCheckBox* m_showPasswordCheck;

    // Event handlers
    void OnLogin(wxCommandEvent& event);
    void OnRegister(wxCommandEvent& event);
    void OnShowPassword(wxCommandEvent& event);

    // Helper functions
    void CreateControls();
    void LayoutControls();

    DECLARE_EVENT_TABLE()
}; 