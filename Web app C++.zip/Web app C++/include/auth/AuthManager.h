#pragma once

#include <string>
#include <wx/string.h>
#include <sqlite3.h>

enum class UserRole {
    Employee,
    Manager,
    Administrator,
    Accountant
};

class AuthManager {
public:
    static AuthManager& getInstance();
    
    bool initialize();
    bool authenticate(const wxString& userId, const wxString& password, UserRole& role);
    bool registerUser(const wxString& userId, const wxString& password, UserRole role);
    bool changePassword(const wxString& userId, const wxString& oldPassword, const wxString& newPassword);

private:
    AuthManager();
    ~AuthManager();
    
    sqlite3* m_db;
    bool createTables();
    bool executeQuery(const std::string& query);
}; 