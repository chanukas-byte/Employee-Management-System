#pragma once

#include <wx/string.h>

class Employee {
public:
    Employee();
    Employee(const wxString& firstName, const wxString& lastName, const wxString& mobile,
            const wxString& address, int age, const wxString& gender, const wxString& email);

    // Getters
    wxString GetFirstName() const { return m_firstName; }
    wxString GetLastName() const { return m_lastName; }
    wxString GetMobile() const { return m_mobile; }
    wxString GetAddress() const { return m_address; }
    int GetAge() const { return m_age; }
    wxString GetGender() const { return m_gender; }
    wxString GetEmail() const { return m_email; }
    double GetSalary() const { return m_salary; }
    bool GetAttendance() const { return m_attendance; }

    // Setters
    void SetFirstName(const wxString& firstName) { m_firstName = firstName; }
    void SetLastName(const wxString& lastName) { m_lastName = lastName; }
    void SetMobile(const wxString& mobile) { m_mobile = mobile; }
    void SetAddress(const wxString& address) { m_address = address; }
    void SetAge(int age) { m_age = age; }
    void SetGender(const wxString& gender) { m_gender = gender; }
    void SetEmail(const wxString& email) { m_email = email; }
    void SetSalary(double salary) { m_salary = salary; }
    void SetAttendance(bool attendance) { m_attendance = attendance; }

private:
    wxString m_firstName;
    wxString m_lastName;
    wxString m_mobile;
    wxString m_address;
    int m_age;
    wxString m_gender;
    wxString m_email;
    double m_salary;
    bool m_attendance;
}; 