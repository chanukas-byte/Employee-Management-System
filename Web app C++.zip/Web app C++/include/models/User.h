#pragma once

#include <wx/string.h>
#include "auth/AuthManager.h"

class User {
public:
    User();
    User(const wxString& userId, const wxString& password, UserRole role);

    // Getters
    wxString GetUserId() const { return m_userId; }
    wxString GetPassword() const { return m_password; }
    UserRole GetRole() const { return m_role; }

    // Setters
    void SetUserId(const wxString& userId) { m_userId = userId; }
    void SetPassword(const wxString& password) { m_password = password; }
    void SetRole(UserRole role) { m_role = role; }

private:
    wxString m_userId;
    wxString m_password;
    UserRole m_role;
}; 